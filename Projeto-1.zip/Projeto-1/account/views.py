from django.shortcuts import render

from django.contrib.auth import login as auth_login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.shortcuts import render, redirect

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.success(request, f'Bem-vindo, {username}!')
                return redirect('blog:home')  # Redireciona para a página inicial após o login
            else:
                messages.error(request, 'Nome de usuário ou senha inválidos.')
        else:
            messages.error(request, 'Nome de usuário ou senha inválidos.')
    else:
        form = AuthenticationForm()
    return render(request, 'account/login.html', {'form': form})

from django.contrib.auth import logout

def user_logout(request):
    logout(request)
    messages.success(request, 'Você foi desconectado com sucesso.')
    return redirect('blog:home')  # Redireciona para a página inicial após o logout

def logged_out(request):
    return render(request, 'logged_out.html')

from django.contrib.auth.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView, PasswordChangeView, PasswordChangeDoneView
from django.contrib.auth.forms import PasswordResetForm, SetPasswordForm
from django.urls import reverse_lazy
from blog.forms import UserRegisterForm, PersonaisDatasForm, PhoneForm

def register(request):
    if request.method == 'POST':
        user_form = UserRegisterForm(request.POST)
        personais_datas_form = PersonaisDatasForm(request.POST)
        phone_form = PhoneForm(request.POST)
        if user_form.is_valid() and personais_datas_form.is_valid() and phone_form.is_valid():
            user = user_form.save()
            personais_datas = personais_datas_form.save(commit=False)
            personais_datas.user = user
            personais_datas.save()
            phone = phone_form.save(commit=False)
            phone.user = user
            phone.save()
            messages.success(request, 'Conta criada com sucesso! Agora você pode fazer login.')
            return redirect('account:login')
        else:
            messages.error(request, 'Erro na criação da conta. Por favor, corrija os erros abaixo.')
            context = {
                'user_form': user_form,
                'personais_datas_form': personais_datas_form,
                'phone_form': phone_form,
            }
            return render(request, 'account/register.html', context)
    else:
        user_form = UserRegisterForm()
        personais_datas_form = PersonaisDatasForm()
        phone_form = PhoneForm()
    return render(request, 'account/register.html', {'user_form': user_form, 'personais_datas_form': personais_datas_form, 'phone_form': phone_form})

class CustomPasswordResetView(PasswordResetView):
    form_class = PasswordResetForm
    template_name = 'account/password_reset.html'
    email_template_name = 'password_reset_email.html'
    success_url = reverse_lazy('password_reset_done')

class CustomPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'password_reset_done.html'

class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    form_class = SetPasswordForm
    template_name = 'password_reset_confirm.html'
    success_url = reverse_lazy('password_reset_complete')

class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'password_reset_complete.html'

class CustomPasswordChangeView(PasswordChangeView):
    template_name = 'account/password_change.html'
    success_url = reverse_lazy('password_change_done')

from django.contrib.auth.decorators import login_required, user_passes_test

def is_admin(user):
    return user.is_staff

@login_required
@user_passes_test(is_admin)
def admin_profile_view(request):
    return render(request, 'account/admin_profile.html')

class CustomPasswordChangeDoneView(PasswordChangeDoneView):
    template_name = 'account/password_change_done.html'

@login_required
def profile_view(request):
    return render(request, 'account/profile.html')
