from django import forms
from django.contrib.auth.forms import UserCreationForm
from django import forms
from .models import Post, Comment, Phone, PersonaisDatas, Category
from django.utils.html import mark_safe


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['image', 'title', 'subtitle', 'content', 'resume', 'category']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0;'}),
            'subtitle': forms.TextInput(attrs={'class': 'form-control', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0;'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0; min-height: 200px;'}),
            'resume': forms.Textarea(attrs={'class': 'form-control', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0; min-height: 100px;'}),
            'category': forms.Select(attrs={'class': 'form-select', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0;'}),
        }

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']
        widgets = {
            'content': forms.Textarea(attrs={'rows': 5, }),
        }

class PhoneForm(forms.ModelForm):
    class Meta:
        model = Phone
        fields = ['number', 'type', 'ddd']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, forms.TextInput) or isinstance(field.widget, forms.EmailInput) or isinstance(field.widget, forms.PasswordInput):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
            elif isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
            elif isinstance(field.widget, forms.Textarea):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'



class PersonaisDatasForm(forms.ModelForm):
    class Meta:
        model = PersonaisDatas
        fields = ['name', 'birth_date', 'zip_code']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, forms.TextInput) or isinstance(field.widget, forms.EmailInput) or isinstance(field.widget, forms.PasswordInput):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
            elif isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
            elif isinstance(field.widget, forms.Textarea):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'

class UserRegisterForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        fields = ('username', 'email')

class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'description', 'image']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0;'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'style': 'background-color: #f8f9fa; border: 1px solid #212529; color: #212529; border-radius: 0; min-height: 100px;'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            if isinstance(field.widget, forms.TextInput) or isinstance(field.widget, forms.EmailInput) or isinstance(field.widget, forms.PasswordInput):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
            elif isinstance(field.widget, forms.Select):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
            elif isinstance(field.widget, forms.Textarea):
                field.widget.attrs['class'] = 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm'
