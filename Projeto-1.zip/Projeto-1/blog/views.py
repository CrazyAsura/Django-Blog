from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import login as auth_login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm, PasswordResetForm, SetPasswordForm, AuthenticationForm
from django.contrib.auth.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView
from django.contrib import messages
from django.core.paginator import Paginator
from django.core import serializers
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy, reverse
from django.http import JsonResponse
from django.db.models import Q
from .models import Post, Comment, Category, PersonaisDatas, Notification, UserProfile
from .forms import PostForm, CommentForm, PhoneForm, PersonaisDatasForm, UserRegisterForm, CategoryForm
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

def home(request):
    categories = Category.objects.all()
    recent_posts = Post.objects.order_by('-created_at')[:6]
    context = {
        'categories': categories,
        'recent_posts': recent_posts,
    }
    return render(request, 'home.html', context)



def news(request):
    query = request.GET.get('q')
    if query:
        posts = Post.objects.filter(
            Q(title__icontains=query) |
            Q(content__icontains=query) |
            Q(category__name__icontains=query)
        ).order_by('-created_at')
    else:
        posts = Post.objects.order_by('-created_at')

    categories = Category.objects.all()
    paginator = Paginator(posts, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'news.html', {'page_obj': page_obj, 'categories': categories, 'query': query})

def new_details(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    post.views += 1
    post.save()
    comments = Comment.objects.filter(post=post).order_by('-created_at')
    

    
    return render(request, 'new_details.html', {
        'post': post,

        'comments': comments
    })

def new_details_by_category(request, category_id, post_id):
    category = get_object_or_404(Category, id=category_id)
    post = get_object_or_404(Post, id=post_id)
    comments = Comment.objects.filter(post=post).order_by('-created_at')

    return render(request, 'new_details.html', {
        'category': category,
        'post': post,

        'comments': comments
    })

@login_required
def add_like(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    
    # If user has disliked, remove dislike
    if request.user in post.dislikes.all():
        post.dislikes.remove(request.user)

    # Add like if not already liked
    if request.user not in post.likes.all():
        post.likes.add(request.user)
    else:
        # If already liked, remove like (toggle behavior)
        post.likes.remove(request.user)
    
    return redirect('blog:new_details', post_id=post_id)

@login_required
def remove_like(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    
    # Remove like if exists
    if request.user in post.likes.all():
        post.likes.remove(request.user)
    
    return redirect('blog:new_details', post_id=post_id)

@login_required
def add_dislike(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    
    # If user has liked, remove like
    if request.user in post.likes.all():
        post.likes.remove(request.user)

    # Add dislike if not already disliked
    if request.user not in post.dislikes.all():
        post.dislikes.add(request.user)
    else:
        # If already disliked, remove dislike (toggle behavior)
        post.dislikes.remove(request.user)
    
    return redirect('blog:new_details', post_id=post_id)

@login_required
def remove_dislike(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    
    # Remove dislike if exists
    if request.user in post.dislikes.all():
        post.dislikes.remove(request.user)
    
    return redirect('blog:new_details', post_id=post_id)

@login_required
def add_comment_like(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user in comment.dislikes.all():
        comment.dislikes.remove(request.user)
    if request.user not in comment.likes.all():
        comment.likes.add(request.user)
    else:
        comment.likes.remove(request.user)
    return redirect('blog:new_details', post_id=comment.post.id)

@login_required
def remove_comment_like(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user in comment.likes.all():
        comment.likes.remove(request.user)
    return redirect('blog:new_details', post_id=comment.post.id)

@login_required
def add_comment_dislike(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user in comment.likes.all():
        comment.likes.remove(request.user)
    if request.user not in comment.dislikes.all():
        comment.dislikes.add(request.user)
    else:
        comment.dislikes.remove(request.user)
    return redirect('blog:new_details', post_id=comment.post.id)

@login_required
def remove_comment_dislike(request, comment_id):
    comment = get_object_or_404(Comment, id=comment_id)
    if request.user in comment.dislikes.all():
        comment.dislikes.remove(request.user)
    return redirect('blog:new_details', post_id=comment.post.id)


def categories(request):
    categories = Category.objects.all()
    return render(request, 'categories.html', {'categories': categories})   

def new_by_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    posts = Post.objects.filter(category=category).order_by('-created_at')
    paginator = Paginator(posts, 6)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'new_by_category.html', {
        'category': category,
        'posts': posts,
        'page_obj': page_obj,
    })

def faq(request):
    return render(request, 'FAQ.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def privacy_policy(request):
    return render(request, 'privacy_policy.html')





@login_required
def notifications_view(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'notifications.html', {'notifications': notifications})

@login_required
def api_notifications(request):
    notifications = Notification.objects.filter(user=request.user, is_read=False).order_by('-created_at')
    data = serializers.serialize('json', notifications)
    return JsonResponse(data, safe=False)


from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

def send_realtime_notification(user, message, notification_type='info', related_url=None):
    notification = Notification.objects.create(
        user=user,
        message=message,
        notification_type=notification_type,
        related_url=related_url
    )
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f'user_{user.id}',
        {
            'type': 'send_notification',
            'message': {
                'id': notification.id,
                'message': notification.message,
                'notification_type': notification.notification_type,
                'related_url': notification.related_url,
                'created_at': notification.created_at.isoformat(),
                'is_read': notification.is_read,
                'priority': notification.priority,
            }
        }
    )


@login_required
def notification_settings(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        user_profile.notification_frequency = request.POST.get('notification_frequency', 'instant')
        user_profile.enable_new_post_notifications = 'enable_new_post_notifications' in request.POST
        user_profile.enable_comment_notifications = 'enable_comment_notifications' in request.POST
        user_profile.save()
        return redirect('blog:notification_settings')

    context = {
        'user_profile': user_profile
    }
    return render(request, 'notification_settings.html', context)

@login_required
def mark_notification_as_read(request, notification_id):
    try:
        notification = Notification.objects.get(id=notification_id, user=request.user)
        notification.is_read = True
        notification.save()
        return JsonResponse({'status': 'success'})
    except Notification.DoesNotExist:
        return JsonResponse({'status': 'error', 'message': 'Notification not found'}, status=404)

@login_required
def mark_all_notifications_as_read(request):
    notifications = Notification.objects.filter(user=request.user, is_read=False)
    for notification in notifications:
        notification.is_read = True
        notification.save()
    return JsonResponse({'status': 'success', 'message': 'All notifications marked as read'})

def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                auth_login(request, user)
                messages.success(request, f'Bem-vindo, {username}!')
                return redirect('home')  # Redireciona para a página inicial após o login
            else:
                messages.error(request, 'Nome de usuário ou senha inválidos.')
        else:
            messages.error(request, 'Nome de usuário ou senha inválidos.')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})


def search_posts_api(request):
    query = request.GET.get('q', '')
    posts = []
    if query:
        posts_query = Post.objects.filter(
            Q(title__icontains=query) |
            Q(subtitle__icontains=query) |
            Q(content__icontains=query) |
            Q(resume__icontains=query)
        ).distinct()[:5]  # Limit to 5 results

        for post in posts_query:
            posts.append({
                'id': post.id,
                'title': post.title,
                'resume': post.resume,
                'image': post.image.url if post.image else '/static/images/default_post.png', # Provide a default image path
                'url': reverse('blog:new_details', args=[post.id])
            })
    return JsonResponse(posts, safe=False)




@login_required
def add_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user.username  # Set the author to the logged-in user's username
            post.save()
            messages.success(request, 'Artigo criado com sucesso!')
            return redirect('blog:new_details', post_id=post.id)
    else:
        form = PostForm()
    return render(request, 'add_post.html', {'form': form})

@login_required
def edit_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            messages.success(request, 'Artigo atualizado com sucesso!')
            return redirect('blog:new_details', post_id=post.id)
    else:
        form = PostForm(instance=post)
    return render(request, 'edit_post.html', {'form': form})

@login_required
def add_category(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Categoria criada com sucesso!')
            return redirect('categories')
    else:
        form = CategoryForm()
    return render(request, 'add_category.html', {'form': form})

@login_required
def edit_category(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    if request.method == 'POST':
        form = CategoryForm(request.POST, request.FILES, instance=category)
        if form.is_valid():
            form.save()
            messages.success(request, 'Categoria atualizada com sucesso!')
            return redirect('categories')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'edit_category.html', {'form': form})




class CustomPasswordResetView(PasswordResetView):
    form_class = PasswordResetForm
    template_name = 'password_reset.html'
    email_template_name = 'password_reset_email.html'
    success_url = reverse_lazy('password_reset_done')

class CustomPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'password_reset_done.html'

class CustomPasswordResetConfirmView(PasswordResetConfirmView):
    form_class = SetPasswordForm
    template_name = 'password_reset_confirm.html'
    success_url = reverse_lazy('password_reset_complete')

class CustomPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'password_reset_complete.html'

