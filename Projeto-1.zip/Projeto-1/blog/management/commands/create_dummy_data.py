import os
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.core.files import File
from django.utils import timezone
from blog.models import Category, Post

class Command(BaseCommand):
    help = 'Creates dummy categories and posts with images.'

    def handle(self, *args, **kwargs):
        self.stdout.write(self.style.SUCCESS('Creating dummy data...'))

        # Create dummy categories
        categories_data = [
            {'name': 'Tecnologia', 'description': 'Notícias sobre tecnologia e inovação.', 'image_path': 'categories/tecnologia.jpeg'},
            {'name': 'Esportes', 'description': 'Notícias e resultados esportivos.', 'image_path': 'categories/esportes.jpeg'},
            {'name': 'Política', 'description': 'Análises e notícias sobre política nacional e internacional.', 'image_path': 'categories/politica.jpeg'},
            {'name': 'Economia', 'description': 'Informações sobre o mercado financeiro e economia.', 'image_path': 'categories/economia.jpeg'},
            {'name': 'Saúde', 'description': 'Dicas e novidades sobre saúde e bem-estar.', 'image_path': 'categories/saude.jpeg'},
        ]

        for data in categories_data:
            category, created = Category.objects.get_or_create(name=data['name'], defaults={'description': data['description']})
            if created:
                image_full_path = os.path.join('c:\\Users\\Leon\\Documents\\web\\blog\\Django\\Projeto-1\\categories', data['image_path'].split('/')[-1])
                if os.path.exists(image_full_path):
                    with open(image_full_path, 'rb') as f:
                        category.image.save(data['image_path'].split('/')[-1], File(f), save=True)
                self.stdout.write(self.style.SUCCESS(f'Successfully created category: {category.name}'))
            else:
                self.stdout.write(self.style.WARNING(f'Category already exists: {category.name}'))

        # Create dummy posts
        posts_data = [
            {
                'title': 'Avanços na Inteligência Artificial',
                'subtitle': 'Novas descobertas prometem revolucionar o setor.',
                'content': 'Pesquisadores anunciam avanços significativos em algoritmos de IA, com aplicações em diversas áreas, desde medicina até automação industrial.',
                'resume': 'IA em constante evolução.',
                'category_name': 'Tecnologia',
                'image_path': 'posts/ia.jpeg'
            },
            {
                'title': 'Olimpíadas 2024: Destaques do Atletismo',
                'subtitle': 'Recordes quebrados e performances memoráveis.',
                'content': 'Acompanhe os principais momentos do atletismo nas Olimpíadas de Paris, com atletas superando limites e emocionando o público.',
                'resume': 'Atletismo nas Olimpíadas.',
                'category_name': 'Esportes',
                'image_path': 'posts/olimpiadas.jpeg'
            },
            {
                'title': 'Reforma Tributária em Debate',
                'subtitle': 'Impactos na economia e no dia a dia dos brasileiros.',
                'content': 'A proposta de reforma tributária continua gerando discussões acaloradas no congresso, com diferentes visões sobre seus efeitos a longo prazo.',
                'resume': 'Reforma tributária em pauta.',
                'category_name': 'Política',
                'image_path': 'posts/reforma.jpeg'
            },
            {
                'title': 'Mercado de Criptomoedas em Alta',
                'subtitle': 'Bitcoin e outras moedas digitais atingem novos picos.',
                'content': 'O valor das criptomoedas disparou nas últimas semanas, atraindo novos investidores e gerando otimismo no mercado financeiro global.',
                'resume': 'Criptomoedas em ascensão.',
                'category_name': 'Economia',
                'image_path': 'posts/cripto.jpeg'
            },
            {
                'title': 'Novas Terapias para Doenças Crônicas',
                'subtitle': 'Esperança para milhões de pacientes ao redor do mundo.',
                'content': 'Cientistas desenvolvem terapias inovadoras que prometem melhorar a qualidade de vida de pacientes com doenças crônicas, oferecendo novas perspectivas de tratamento.',
                'resume': 'Terapias revolucionárias.',
                'category_name': 'Saúde',
                'image_path': 'posts/saude.jpeg'
            },
        ]

        admin_user = User.objects.filter(is_superuser=True).first()
        if not admin_user:
            self.stdout.write(self.style.ERROR('No superuser found. Please create a superuser first (python manage.py createsuperuser).'))
            return

        for data in posts_data:
            category = Category.objects.get(name=data['category_name'])
            post, created = Post.objects.get_or_create(
                title=data['title'],
                defaults={
                    'subtitle': data['subtitle'],
                    'content': data['content'],
                    'resume': data['resume'],
                    'category': category,
                    'author': admin_user.username,
                }
            )
            if created:
                image_full_path = os.path.join('c:\\Users\\Leon\\Documents\\web\\blog\\Django\\Projeto-1\\posts', data['image_path'].split('/')[-1])
                if os.path.exists(image_full_path):
                    with open(image_full_path, 'rb') as f:
                        post.image.save(data['image_path'].split('/')[-1], File(f), save=True)
                self.stdout.write(self.style.SUCCESS(f'Successfully created post: {post.title}'))
            else:
                self.stdout.write(self.style.WARNING(f'Post already exists: {post.title}'))

        self.stdout.write(self.style.SUCCESS('Dummy data creation complete.'))