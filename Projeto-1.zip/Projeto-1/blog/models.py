from os import name
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.utils.translation import gettext_lazy as _

User = get_user_model()

class Post(models.Model):
    image = models.ImageField(upload_to='posts/', blank=True, null=True)
    author = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    subtitle = models.CharField(max_length=255)
    resume = models.TextField(max_length=255)
    content = models.TextField()
    category = models.ForeignKey('Category', on_delete=models.CASCADE, related_name='posts')
    views = models.PositiveIntegerField(default=0)
    likes = models.ManyToManyField(User, related_name='liked_posts', blank=True)
    dislikes = models.ManyToManyField(User, related_name='disliked_posts', blank=True)
    number_of_comments = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = _('Post')
        verbose_name_plural = _('Posts')

    def like_count(self):
        return self.likes.count()
    
    def dislike_count(self):
        return self.dislikes.count()
    
    def get_absolute_url(self):
        from django.urls import reverse
        return reverse('new_details', args=[str(self.id)])

    def __str__(self):
        return self.title
    
class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')
    name = models.CharField(max_length=255, null=True, blank=True)
    email = models.EmailField(null=True, blank=True)
    content = models.TextField()
    likes = models.ManyToManyField(User, related_name='liked_comments', blank=True)
    dislikes = models.ManyToManyField(User, related_name='disliked_comments', blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = _('Comment')
        verbose_name_plural = _('Comments')

    def like_count(self):
        return self.likes.count()
    
    def dislike_count(self):
        return self.dislikes.count()

    def __str__(self):
        return f'Comment by {self.name} on {self.post.title}'
    
class Category(models.Model):
    image = models.ImageField(upload_to='categories/', blank=True, null=True)
    name = models.CharField(max_length=255, unique=True)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['name']
        verbose_name = _('Category')
        verbose_name_plural = _('Categories')

    def __str__(self):
        return self.name

class PersonaisDatas(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='personal_datas')
    name = models.CharField(max_length=255, null=True, blank=True)
    birth_date = models.DateField(null=True, blank=True)
    zip_code = models.CharField(max_length=20)
    
class Phone(models.Model):
    PHONE_TYPES = [
        ('mobile', _('Mobile')),
        ('home', _('Home')),
        ('work', _('Work')),
    ]

    DDD_TYPES = [
        ('11', '11'), ('12', '12'), ('13', '13'), ('14', '14'), ('15', '15'),
        ('16', '16'), ('17', '17'), ('18', '18'), ('19', '19'), ('21', '21'),
        ('22', '22'), ('24', '24'), ('27', '27'), ('28', '28'), ('31', '31'),
        ('32', '32'), ('33', '33'), ('34', '34'), ('35', '35'), ('37', '37'),
        ('38', '38'), ('41', '41'), ('42', '42'), ('43', '43'), ('44', '44'),
        ('45', '45'), ('46', '46'), ('47', '47'), ('48', '48'), ('49', '49'),
        ('51', '51'), ('53', '53'), ('54', '54'), ('55', '55'), ('61', '61'),
        ('62', '62'), ('63', '63'), ('64', '64'), ('65', '65'), ('66', '66'),
        ('67', '67'), ('68', '68'), ('69', '69'), ('71', '71'), ('73', '73'),
        ('74', '74'), ('75', '75'), ('77', '77'), ('79', '79'), ('81', '81'),
        ('82', '82'), ('83', '83'), ('84', '84'), ('85', '85'), ('86', '86'),
        ('87', '87'), ('88', '88'), ('89', '89'), ('91', '91'), ('92', '92'),
        ('93', '93'), ('94', '94'), ('95', '95'), ('96', '96'), ('97', '97'),
        ('98', '98'), ('99', '99')
    ]    
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='phones')
    number = models.CharField(max_length=20)
    ddd = models.CharField(max_length=2, choices=DDD_TYPES)
    type = models.CharField(max_length=6, choices=PHONE_TYPES)

    class Meta:
        verbose_name = _('Phone')
        verbose_name_plural = _('Phones')

    def __str__(self):
        return f'{self.get_type_display()}: ({self.ddd}) {self.number}'

    def clean(self):
        if not self.number.isdigit():
            raise ValidationError(_('Phone number must contain only digits'))

from django.db.models import JSONField

class Notification(models.Model):
    PRIORITY_CHOICES = [
        ('urgent', 'Urgent'),
        ('important', 'Important'),
        ('routine', 'Routine'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications', null=True, blank=True)
    message = models.CharField(max_length=255)
    notification_type = models.CharField(max_length=50, default='info') # e.g., 'new_post', 'comment', 'like'
    related_url = models.URLField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='routine')
    user_preferences = JSONField(default=dict, blank=True, null=True)

    class Meta:
        ordering = ['-created_at']
        verbose_name = _('Notification')
        verbose_name_plural = _('Notifications')

    def __str__(self):
        return self.message

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='userprofile')
    notification_frequency = models.CharField(max_length=10, default='instant', choices=[
        ('instant', 'Instantânea'),
        ('daily', 'Diária'),
        ('weekly', 'Semanal'),
    ])
    enable_new_post_notifications = models.BooleanField(default=True)
    enable_comment_notifications = models.BooleanField(default=True)

    class Meta:
        verbose_name = _('User Profile')
        verbose_name_plural = _('User Profiles')

    def __str__(self):
        return f'Profile for {self.user.username}'

from django.db.models.signals import post_save
from django.dispatch import receiver

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.userprofile.save()