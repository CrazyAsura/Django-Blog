from django.shortcuts import render
from blog.models import Post, Comment
from django.db.models import Count

def dashboard_view(request):
    # Get total views for all posts
    total_views = Post.objects.aggregate(total_views=Count('views'))['total_views']

    # Get total likes and dislikes for posts
    total_post_likes = Post.objects.aggregate(total_likes=Count('likes'))['total_likes']
    total_post_dislikes = Post.objects.aggregate(total_dislikes=Count('dislikes'))['total_dislikes']

    # Get total likes and dislikes for comments
    total_comment_likes = Comment.objects.aggregate(total_likes=Count('likes'))['total_likes']
    total_comment_dislikes = Comment.objects.aggregate(total_dislikes=Count('dislikes'))['total_dislikes']

    posts = Post.objects.all()
    comments = Comment.objects.all()

    context = {
        'total_views': total_views,
        'total_post_likes': total_post_likes,
        'total_post_dislikes': total_post_dislikes,
        'total_comment_likes': total_comment_likes,
        'total_comment_dislikes': total_comment_dislikes,
        'posts': posts,
        'comments': comments,
    }
    return render(request, 'dashboard/dashboard.html', context)
