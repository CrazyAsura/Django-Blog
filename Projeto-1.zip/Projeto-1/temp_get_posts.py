import sys
from blog.models import Post
for post in Post.objects.all():
    print(f'Title: {post.title}, Resume: {post.resume}, Content: {post.content}')
sys.exit()